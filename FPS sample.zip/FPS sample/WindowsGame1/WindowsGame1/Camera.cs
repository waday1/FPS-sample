﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using SkinnedModel;
namespace WindowsGame1
{
    /// <summary>
    /// カメラ
    /// </summary>
    public class Camera
    {
        #region フィールド
        /// <summary>
        /// カメラ位置
        /// </summary>
        public Vector3 Position
        {
            get { return position; }
        }
        public Vector3 position = Vector3.Zero;

        /// <summary>
        /// ターゲットのいち
        /// </summary>
        public Vector3 ReferenceTranslate
        {
            get { return referenceTranslate; }
            set { referenceTranslate = value;  }
        }
        public Vector3 referenceTranslate = new Vector3(0.0f, 0.0f, -200.0f);

        /// <summary>
        /// 回転適用済みの位置
        /// </summary>
        public Vector3 TransformedReference
        {
            get { return transformedReference; }
        }
        public Vector3 transformedReference = new Vector3(0.0f, 10.0f, -10.0f);

        /// <summary>
        /// アスペクト比
        /// </summary>
        public float AspectRatio
        {
            get { return aspectRatio; }
            set { aspectRatio = value; }
        }
        float aspectRatio = 4.0f / 3.0f;

        /// <summary>
        /// 視野角
        /// </summary>
        public float FieldOfView
        {
            get { return fieldOfView; }
            set { fieldOfView = value;  }
        }
        float fieldOfView = MathHelper.ToRadians(45.0f);

        /// <summary>
        /// ニアクリップ面の距離
        /// </summary>
        public float NearPlaneDistance
        {
            get { return nearPlaneDistance; }
            set { nearPlaneDistance = value;  }
        }
        private float nearPlaneDistance = 1.0f;

        /// <summary>
        /// ファークリップ面の距離
        /// </summary>
        public float FarPlaneDistance
        {
            get { return farPlaneDistance; }
            set { farPlaneDistance = value;  }
        }
        private float farPlaneDistance = 1000.0f;

        /// <summary>
        /// ビュー行列
        /// </summary>
        public Matrix View
        {
            get { return view; }
        }
        public Matrix view;

        /// <summary>
        /// 射影行列
        /// </summary>
        public Matrix Projection
        {
            get { return projection; }
        }
        public Matrix projection;

        
        private Vector3 rotation = Vector3.Zero;

        /// <summary>
        /// カメラの回転行列
        /// </summary>
        public Matrix rotationMatrix = Matrix.Identity;

        private Vector3 avatarHeadOffset;
        public Vector3 AvatarHeadOffset
        {
            get { return avatarHeadOffset; }
            set { avatarHeadOffset = value;  }
        }

        public Vector3 headOffset;

        public Vector3 cameraLookat;
        #endregion

        public Camera( GraphicsDevice graphicsDevice)
        {
            fieldOfView = MathHelper.ToRadians(45.0f);
            aspectRatio = (float)graphicsDevice.Viewport.Width / (float)graphicsDevice.Viewport.Height;
            nearPlaneDistance = 1.0f;
            farPlaneDistance = 1500.0f;
            referenceTranslate = new Vector3(0.0f, 180.0f, 800.0f);
            avatarHeadOffset = new Vector3(0.0f, 180.0f, 10.0f);
        }
        public void Initialize(ModelComponent avatarmodelComponent, GraphicsDeviceManager graphics, GraphicsDevice graphicsDevice)
        {
            // 最初に更新しておく
            Calculate( avatarmodelComponent);
        }

        private void Calculate(ModelComponent avatarmodelComponent)
        {
        }

        public void Update(GameTime gameTime, ModelComponent avatarmodelComponent)
        {
            Rotation();

            Zoom();

            // 行列の計算、計算が必要なときのみ処理する
            Calculate(  avatarmodelComponent);
        }
        public void Rotation()
        {
            float cameraSpeed = 0.05f;
            Vector2 leftStick = InputManager.GetThumbSticksRight(PlayerIndex.One) * cameraSpeed;
            float YAngleMax = 60f;
        }

        public void Zoom()
        {
            float zoomSpeed = 10f;
        }
    }
}
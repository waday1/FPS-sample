﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using SkinnedModel;

namespace WindowsGame1
{
    class ObjectModelComponent
    {
        public ModelComponent modelComponent;

        private Matrix[] transform;

        public ObjectModelComponent()
        {

        }

        public void Load(string assetName, Game game, Vector3 position, Vector3 rotation, float scale)
        {
            modelComponent = new ModelComponent(assetName, game, position, rotation, scale);

            transform = new Matrix[modelComponent.model.Bones.Count];
            modelComponent.model.CopyAbsoluteBoneTransformsTo(transform);
        }

        public void Update()
        {
            modelComponent.WorldUpdate();
        }

        public void Draw(Camera camera)
        {
            Matrix view = camera.View;
            Matrix projection = camera.Projection;
            foreach (ModelMesh mesh in modelComponent.model.Meshes)
            {
                foreach (BasicEffect effect in mesh.Effects)
                {
                    effect.PreferPerPixelLighting = true;

                    effect.EnableDefaultLighting();

                    effect.View =view;
                    effect.Projection = projection;
                    effect.World = transform[mesh.ParentBone.Index] * modelComponent.worldMatrix;

                    effect.DirectionalLight0.Enabled = true;
                    effect.DirectionalLight1.Enabled = false;
                    effect.DirectionalLight2.Enabled = false;
                }

                mesh.Draw();
            }

        }
    }
}

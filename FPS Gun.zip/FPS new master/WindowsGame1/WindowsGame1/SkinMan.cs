﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using SkinnedModel;

namespace WindowsGame1
{
    class SkinMan
    {
        public enum ClipNames
        {
            idle,
            walk,
            jump,
            run,
            set,
            ready,
            winner,
            appeal
        };

        /// アニメーションデータ
        private SkinningData skinningData;

        /// アニメーションプレーヤー
        private AnimationPlayer animationPlayer;

        /// クリップ名配列のインデックス
        public int clipIndex;

        /// クリップ名配列
        /// これはこのサンプルで使用しているC_Skinman.fbxに組み込まれているものです。
        public string[] clipNames = { "idle", "walk", "jump", "run", "set", "ready", "winner", "appeal" };

        /// アニメーションのループ再生フラグ
        bool loopEnable;
        /// アニメーションの一時停止フラグ
        bool pauseEnable;

        /// アニメーションのスローモーション再生速度
        /// １より大きくなるにしたがって再生速度が遅くなります。
        int slowMotionOrder;
        int slowMotionCount;

        public ModelComponent modelComponent;

        public ObjectModelComponent gun;
        public Vector3 gunPos;

        public SkinMan()
        {
            gun = new ObjectModelComponent();
            gunPos = new Vector3(0, 160, 20);
        }

        public void Initialize()
        {
            // アニメーション用データを初期化
            InitializeAnimationValue();

            // 各種座標データを初期化
            InitializeCoordinateValue();
        }
        /// アニメーション用の変数を初期化
        private void InitializeAnimationValue()
        {
            // クリップ名配列インデックスを初期化
            clipIndex = 0;

            // ループ再生を有効
            loopEnable = true;

            // 一時停止フラグを無効
            pauseEnable = false;

            // スローモーション速度を等速
            slowMotionOrder = 0;
            slowMotionCount = 0;
        }
        /// 座標データの初期化
        public void InitializeCoordinateValue()
        {
            modelComponent.position = Vector3.Zero;
            modelComponent.rotation = Vector3.Zero;
            modelComponent.worldMatrix = Matrix.Identity;
        }

        /// スキンモデルの読み込み処理
        public void Load(string assetName,Game game)
        {
            modelComponent = new ModelComponent(assetName, game, Vector3.Zero, Vector3.Zero, 1f);

            // SkinningDataを取得
            skinningData =modelComponent. model.Tag as SkinningData;

            if (skinningData == null)
                throw new InvalidOperationException
                    ("This model does not contain a SkinningData tag.");

            // AnimationPlayerを作成
            animationPlayer = new AnimationPlayer(skinningData);

            // アニメーションを再生する
            ChangeAnimationClip(clipNames[clipIndex], loopEnable, 0.0f);

            gun.Load("Colt_Python", game, new Vector3(0, 160, 100), Vector3.Zero, 2f);
        }


        #region アニメーションの操作
        /// アニメーションの切替処理
        public void ChangeAnimationClip(string clipName, bool loop, float weight)
        {
            // クリップ名からAnimationClipを取得して再生する
            AnimationClip clip = skinningData.AnimationClips[clipName];

            animationPlayer.StartClip(clip, loop, weight);
        }
        #endregion

        /// アニメーションの更新
        public void UpdateAnimation(GameTime gameTime, bool relativeToCurrentTime)
        {
            // 一時停止状態でないか？
            if (pauseEnable)
                return;

            // スローモーションが有効か？
            if (slowMotionOrder > 0)
            {
                if (slowMotionCount > 0)
                {
                    slowMotionCount--;
                    return;
                }
                slowMotionCount = slowMotionOrder;
            }

            // アニメーションの更新
            animationPlayer.Update(gameTime.ElapsedGameTime, true, modelComponent.worldMatrix);
        }


        #region 入力による処理
        /// 入力による処理
        public void UpdateInput(GameTime gameTime)
        {
            // モデルの座標を更新
            UpdateModelCoordinates(gameTime);

            // アニメーションの操作
            UpdateAnimationControl(gameTime);

        }

        /// モデルの座標を更新
        private void UpdateModelCoordinates(GameTime gameTime)
        {
            // 移動速度として取得
            float velocity = (float)gameTime.ElapsedGameTime.TotalMilliseconds * 0.1f;

            // 計算用のベクトル
            Vector3[] vec = new Vector3[2];

            for (int i = 0; i < vec.Length; i++)
            {
                vec[i] = Vector3.Zero;
            }

            float speed = 3.0f;

            // 左右スティックの入力を取得する
            Vector2 leftStick = Vector2.Zero;
            Vector2 rightStick = Vector2.Zero;

            leftStick = InputManager.GetThumbSticksLeft(PlayerIndex.One) * speed;
            rightStick = InputManager.GetThumbSticksRight(PlayerIndex.One) * speed;

            // ゲームパッドでの回転操作
            float cameraSpeed = 0.01f;

            modelComponent.rotation.Y += -rightStick.X * cameraSpeed;

            // ゲームパッドでの移動操作
            // 上下左右移動
            vec[0].X = -leftStick.X * (float)Math.Cos(modelComponent.rotation.Y) + leftStick.Y * (float)Math.Sin(modelComponent.rotation.Y);
            vec[0].Z = leftStick.Y * (float)Math.Cos(modelComponent.rotation.Y) + leftStick.X * (float)Math.Sin(modelComponent.rotation.Y);

            // 入力があったときのみ処理する(入力がなければ長さは0.0fとなるため)
            if (vec[0].Length() > 0.0f || vec[1].Length() > 0.0f)
            {
                // 移動する
                modelComponent.position += (vec[0] + vec[1]) * speed;
                clipIndex = 1;
                loopEnable = true;
            }
            else
            {
                clipIndex = 0;
            }


            modelComponent.WorldUpdate();

            // 初期値に戻す
            if (InputManager.IsJustButtonDown(PlayerIndex.One, Buttons.RightStick) || InputManager.IsJustKeyDown(Keys.R))
            {
                // 各種座標データを初期化
                InitializeCoordinateValue();
            }

            gun.modelComponent.position = modelComponent.position;
            gun.modelComponent.position.Z += -100 * (float)Math.Cos(gun.modelComponent.rotation.Y);
            gun.modelComponent.position.X += -100 * (float)Math.Sin(gun.modelComponent.rotation.Y);
            gun.modelComponent.position.Y += 100;

            gun.modelComponent.rotation.Y =modelComponent.rotation.Y+MathHelper.ToRadians(  180)  ;

            gun.Update();
        }

        /// <summary>
        /// アニメーションの操作
        /// </summary>
        private void UpdateAnimationControl(GameTime gameTime)
        {
            // スロー再生操作
            if (InputManager.IsJustPressedDPadLeft(PlayerIndex.One) || InputManager.IsJustKeyDown(Keys.Left))
                slowMotionOrder += 1;
            if (InputManager.IsJustPressedDPadRight(PlayerIndex.One) || InputManager.IsJustKeyDown(Keys.Right))
                slowMotionOrder -= 1;

            // 範囲を超えたら初期化
            if (slowMotionOrder <= 0)
            {
                slowMotionOrder = 0;
                slowMotionCount = 0;
            }

            // 一時停止操作
            if (InputManager.IsJustButtonDown(PlayerIndex.One, Buttons.Start) || InputManager.IsJustKeyDown(Keys.V))
                pauseEnable = (pauseEnable) ? false : true;

            // クリップ名変更操作
            if (InputManager.IsJustPressedDPadUp(PlayerIndex.One) || InputManager.IsJustKeyDown(Keys.Up))
            {
                clipIndex++;
                loopEnable = true;

                // ループ再生を禁止するか？
                if (InputManager.IsButtonDown(PlayerIndex.One, Buttons.B) || InputManager.IsKeyDown(Keys.LeftControl))
                    loopEnable = false;

            }
            if (InputManager.IsJustPressedDPadDown(PlayerIndex.One) || InputManager.IsJustKeyDown(Keys.Down))
            {
                clipIndex--;
                loopEnable = true;

                // ループ再生を禁止するか？
                if (InputManager.IsButtonDown(PlayerIndex.One, Buttons.B) || InputManager.IsKeyDown(Keys.LeftControl))
                    loopEnable = false;
            }

            // 範囲を超えたら初期化
            if (clipIndex >= clipNames.Length)
                clipIndex = clipNames.Length - 1;
            if (clipIndex < 0)
                clipIndex = 0;

            // クリップに変更があったか？
            if (animationPlayer.CurrentClip.Name.CompareTo(clipNames[clipIndex]) != 0)
                // クリップを切り替える
                ChangeAnimationClip(clipNames[clipIndex], loopEnable, 0.0f);


            // 初期値に戻す
            if (InputManager.IsJustButtonDown(PlayerIndex.One, Buttons.X) || InputManager.IsJustKeyDown(Keys.N))
            {
                // アニメーション用データを初期化
                InitializeAnimationValue();
                // クリップを切り替える
                ChangeAnimationClip(clipNames[0], true, 0.0f);
            }
        }
        #endregion


        public void Draw(Camera camera)
        {
            Matrix[] bones = animationPlayer.GetSkinTransforms();
            Matrix view = camera.View;
            Matrix projection = camera.Projection;

            // モデルを描画
            foreach (ModelMesh mesh in modelComponent.model.Meshes)
            {
                string name = mesh.Name;
                foreach (SkinnedEffect effect in mesh.Effects)
                {
                    effect.SetBoneTransforms(bones);
                    effect.View = view;
                    effect.Projection = projection;
                }

                mesh.Draw();
            }


            gun.Draw(camera);
        }
    }
}

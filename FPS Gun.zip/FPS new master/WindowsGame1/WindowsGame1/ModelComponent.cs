﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using SkinnedModel;

namespace WindowsGame1
{
    public class ModelComponent
    {
        public Model model;

        public Vector3 position;

        public Vector3 rotation;

        public float scale;

        public Matrix worldMatrix;

        public ModelComponent(string assetName, Game game, Vector3 position, Vector3 rotation, float scale)
        {
            model = game.Content.Load<Model>(assetName);

            this.position = position;

            this.rotation = rotation;

            this.scale = scale;
        }

        public void WorldUpdate()
        {
            Matrix scalingMatrix = Matrix.CreateScale(scale);

            Matrix rotationMatrix = Matrix.CreateRotationX(rotation.X) * Matrix.CreateRotationY(rotation.Y) * Matrix.CreateRotationZ(rotation.Z);

            // 平行移動行列の作成
            Matrix translationMatrix = Matrix.CreateTranslation(position);

            worldMatrix = scalingMatrix * rotationMatrix * translationMatrix;
            
        }
    }
}

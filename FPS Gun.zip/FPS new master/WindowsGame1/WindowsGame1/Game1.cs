﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using SkinnedModel;

namespace WindowsGame1
{
    /// <summary>
    /// 基底 Game クラスから派生した、ゲームのメイン クラスです。
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        #region フィールド
        /// <summary>
        /// グラフィックスデバイスマネージャー
        /// </summary>
        GraphicsDeviceManager graphics;

        SkinMan skinMan;

        Ground ground;

        ObjectModelComponent[] box=new ObjectModelComponent[5];

        /// <summary>
        /// カメラ
        /// </summary>
        private Camera camera;


        /// <summary>
        /// スプライトバッチ
        /// </summary>
        private SpriteBatch spriteBatch;

        /// <summary>
        /// スプライトフォント
        /// </summary>
        private SpriteFont font;

        #endregion

        #region コンストラクタ
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public Game1()
        {
            // デバイスマネージャの生成する
            graphics = new GraphicsDeviceManager(this);

            // コンテントのディレクトリを"Content"に設定する
            Content.RootDirectory = "Content";
        }
        #endregion

        #region 初期化
        /// <summary>
        /// 初期化のタイミングにフレームワークから呼び出されます
        /// </summary>
        protected override void Initialize()
        {
            // インプットマネージャーの初期化
            InputManager.Initialize();

            skinMan = new SkinMan();

            ground = new Ground();

            for (int i = 0; i < box.Length;i++ )
                box[i] = new ObjectModelComponent();

            // カメラの初期化
            InitializeCamera();

            base.Initialize();
        }

        /// <summary>
        /// カメラの初期化
        /// </summary>
        private void InitializeCamera()
        {
            // カメラを生成する
            camera = new Camera(GraphicsDevice);

        }
        #endregion

        #region コンテンツの読み込み処理
        /// <summary>
        /// コンテンツ読み込みのタイミングにフレームワークから呼び出されます
        /// </summary>
        protected override void LoadContent()
        {
            // スプライトバッチの作成
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // スプライトフォントの作成
            font = Content.Load<SpriteFont>(@"SpriteFont1");

            skinMan.Load(@"C_Skinman",this);

            ground.Load("yuka", this,Vector3.Zero,Vector3.Zero,3f);


            box[0].Load("sikaku", this, new Vector3(0, 0, 0), Vector3.Zero, 1f);
            box[1].Load("sikaku", this, new Vector3(0, 0, 800), Vector3.Zero, 1f);
            box[2].Load("sikaku", this, new Vector3(800, 0, 0), Vector3.Zero, 1f);
            box[3].Load("sikaku", this, new Vector3(0, 0, -800), Vector3.Zero, 1f);
            box[4].Load("sikaku", this, new Vector3(-800, 0, 0), Vector3.Zero, 1f);
            
        }


        #endregion

        #region コンテンツの解放処理
        /// <summary>
        /// コンテンツ解放のタイミングにフレームワークから呼び出されます
        /// </summary>
        protected override void UnloadContent()
        {
        }
        #endregion


        #region ゲームの更新処理
        /// <summary>
        /// アップデートのタイミングにフレームワークから呼び出されます
        /// </summary>
        /// <param name="gameTime">ゲームタイム</param>
        protected override void Update(GameTime gameTime)
        {
            // インプットマネージャーのアップデート
            InputManager.Update();

            // 終了ボタンのチェック
            if (InputManager.IsJustKeyDown(Keys.Escape) || InputManager.IsJustButtonDown(PlayerIndex.One, Buttons.Back))
                Exit();

            // 入力を取得する
            skinMan.UpdateInput(gameTime);

            ground.Update();

            for (int i = 0; i < box.Length; i++)
                box[i].Update();

            // カメラの更新
            camera.Update(gameTime,skinMan.modelComponent);

            // アニメーションの更新
            skinMan.UpdateAnimation(gameTime, true);

            base.Update(gameTime);
        }
        #endregion


        #region ゲームの描画処理
        /// <summary>
        /// 描画のタイミングにフレームワークから呼び出されます
        /// </summary>
        /// <param name="gameTime">ゲームタイム</param>
        protected override void Draw(GameTime gameTime)
        {
            // 背景を塗りつぶす
            graphics.GraphicsDevice.Clear(Color.CornflowerBlue);

            skinMan.Draw(camera);

            ground.Draw(camera);

            for (int i = 0; i < box.Length; i++)
                box[i].Draw(camera);

            base.Draw(gameTime);
        }
        #endregion
    }
}
